﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace JogoDaVelha
{
    class Program
    {

        static void Main(string[] args)
        {
            new Jogo().Iniciar();
        }
    }
}
